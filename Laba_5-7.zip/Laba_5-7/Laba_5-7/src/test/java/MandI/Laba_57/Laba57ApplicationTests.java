package MandI.Laba_57;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Laba57ApplicationTests {

	@Test
	void contextLoads() {
	}

}
