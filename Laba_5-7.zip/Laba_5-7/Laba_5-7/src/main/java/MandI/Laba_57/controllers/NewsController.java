package MandI.Laba_57.controllers;
import MandI.Laba_57.models.File;
import MandI.Laba_57.models.News;
import MandI.Laba_57.repository.NewsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Optional;

@Controller
public class NewsController {
    @Autowired
    private NewsRepository newsRepository;
    @GetMapping("/news") //тут все новости
    public String newsMain(Model model){
        Iterable<News> news =newsRepository.findAll();
        model.addAttribute("news",news);
        return "news";
    }

    @GetMapping("/news/{id}")//подробный текст новостей
    public String newsDetails(@PathVariable(value = "id") long id, Model model){
        if (!newsRepository.existsById(id)){
            return "redirect:/news";
        }
        Optional<News> optionalNews = newsRepository.findById(id);
        if (optionalNews.isPresent()) {
            News news = optionalNews.get();
            // Увеличьте счетчик просмотров
            news.incrementViews();
            // Сохраните обновленный объект News, чтобы сохранить изменения
            newsRepository.save(news);
            // Далее ваш код для передачи объекта News в модель и отображения шаблона
            ArrayList<News> res = new ArrayList<>();
            res.add(news);
            model.addAttribute("_new", res);
            return "news-details";
        } else {
            return "redirect:/news";
        }
    }

    @GetMapping("/news/{id}/download")
    public ResponseEntity<Resource> blogPostDownload(@PathVariable( value = "id") long id) throws Exception {
        News news = newsRepository.findById(id).orElseThrow();
        File file = news.getFile();
        InputStreamResource resource = new InputStreamResource(new ByteArrayInputStream(file.getBytes()));
        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + file.getOriginalFileName());
        header.add("Cache-Control", "no-cache, no-store, must-revalidate");
        header.add("Pragma", "no-cache");
        header.add("Expires", "0");
        return ResponseEntity.ok()
                .headers(header)
                .contentLength(file.getSize())
                .contentType(MediaType.parseMediaType(file.getContentType()))
                .body(resource);
    }
}
