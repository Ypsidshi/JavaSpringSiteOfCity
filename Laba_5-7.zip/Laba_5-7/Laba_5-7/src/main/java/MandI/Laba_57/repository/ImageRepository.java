package MandI.Laba_57.repository;

import MandI.Laba_57.models.Image;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ImageRepository extends JpaRepository<Image,Long> {
}
