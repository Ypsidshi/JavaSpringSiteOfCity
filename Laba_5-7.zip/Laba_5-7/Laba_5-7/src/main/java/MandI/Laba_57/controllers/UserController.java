package MandI.Laba_57.controllers;

import MandI.Laba_57.models.User;
import MandI.Laba_57.service.UserService;
/*import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@RequiredArgsConstructor
public class UserController {
    private final UserService userService;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/registration")
    public String registration() {
        return "registration";
    }


    @PostMapping("/registration")
    public String createUser(User user, Model model) {
        if (!userService.createUser(user)) {
            model.addAttribute("errorMessage", "Пользователь с email: " + user.getEmail() + " уже существует");
            return "registration";
        }
        return "redirect:/login";
    }

    @GetMapping("/user/{user}")
    public String userInfo(@PathVariable("user") User user, Model model) {
        model.addAttribute("user", user);
        return "user-info";
    }

}*/

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Optional;

@Controller
@RequiredArgsConstructor
public class UserController {
    private final UserService userService;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/profile")
    public String profile(Principal principal, Model model) {
        User user = userService.getUserByPrincipal(principal);
        model.addAttribute("user", user);
        return "Cabinet";
    }

    @GetMapping("/registration")
    public String registration() {
        return "registration";
    }

    @PostMapping("/registration")
    public String createUser(User user, Model model) {
        if (!userService.createUser(user)) {
            model.addAttribute("errorMessage", "Пользователь с email: " + user.getEmail() + " уже существует");
            return "registration";
        }
        return "redirect:/login";
    }

    @PostMapping("/user/uploadAvatar")
    public String uploadAvatar(@RequestParam("avatar") MultipartFile avatar, Principal principal) throws IOException {
        userService.uploadAvatar(principal, avatar);
        return "redirect:/profile";
    }

    @PostMapping("/user/deleteAvatar")
    public String deleteAvatar(Principal principal) {
        userService.deleteAvatar(principal.getName());
        return "redirect:/profile";
    }

    @GetMapping("/user/{id}/edit")// меняем данные для новости
    public String userEdit(@PathVariable(value = "id") long id, Model model){
        if (!userService.existsById(id)){
            return "redirect:/";
        }
        Optional<User> _user = userService.findById(id);
        ArrayList<User> res = new ArrayList<>();
        _user.ifPresent(res::add);
        model.addAttribute("_user", res);
        return "user-edit";
    }

    @PostMapping("/user/{id}/edit") //получение данных из полей и сохранение новые данные пользователя
    public String userUpdate(@PathVariable(value = "id") long id, @RequestParam String name, @RequestParam String phoneNumber, Model model){
        User user = userService.findById(id).orElseThrow();
        user.setName(name);
        user.setPhoneNumber(phoneNumber);
        userService.save(user);
        return "redirect:/profile";
    }

    @GetMapping("/user/{user}")
    public String userInfo(@PathVariable("user") User user, Model model) {
        model.addAttribute("user", user);
        return "user-info";
    }


}