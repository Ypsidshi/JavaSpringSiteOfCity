package MandI.Laba_57.controllers;

import MandI.Laba_57.models.News;
import MandI.Laba_57.repository.NewsRepository;
import MandI.Laba_57.service.NewsService;
import MandI.Laba_57.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;

@Controller
@RequiredArgsConstructor
@PreAuthorize("hasAuthority('ADMIN') or hasAuthority('MODER')")
public class ModeratorController {
    @Autowired
    private NewsRepository newsRepository;

    private final NewsService newsService;

    @GetMapping("/moder") //тут все новости
    public String newsMain(Model model){
        Iterable<News> news =newsRepository.findAll();
        model.addAttribute("news",news);
        return "moderPanel";
    }

    @GetMapping("/news/add") //добавить новость
    public String newsAdd(Model model){
        return "news-add";
    }

    @PostMapping("/news/add") //получение данных из полей и сохранение новости
    public String newsAdd(@RequestParam String title, @RequestParam String anons, @RequestParam String full_text, @RequestParam MultipartFile file, Model model) throws IOException {
        News news = new News(title,anons, full_text);
        newsService.createNews(news, file);
        return "redirect:/moder";
    }

    @GetMapping("/news/{id}/edit")// меняем текст новости
    public String newsEdit(@PathVariable(value = "id") long id, Model model){
        if (!newsRepository.existsById(id)){
            return "redirect:/moder";
        }
        Optional<News> _new = newsRepository.findById(id);
        ArrayList<News> res = new ArrayList<>();
        _new.ifPresent(res::add);
        model.addAttribute("_new", res);
        return "news-edit";
    }

    @PostMapping("/news/{id}/edit") //получение данных из полей и сохранение новости
    public String newsUpdate(@PathVariable(value = "id") long id, @RequestParam String title, @RequestParam String anons,@RequestParam String full_text, Model model){
        News news = newsRepository.findById(id).orElseThrow();
        news.setTitle(title);
        news.setAnons(anons);
        news.setFull_text(full_text);
        newsRepository.save(news);
        return "redirect:/moder";
    }

    @PostMapping("/news/{id}/remove") //удаляем новость по айдишнику
    public String newsDelete(@PathVariable(value = "id") long id, Model model){
        News news = newsRepository.findById(id).orElseThrow();
        newsRepository.delete(news);
        return "redirect:/moder";
    }
}
