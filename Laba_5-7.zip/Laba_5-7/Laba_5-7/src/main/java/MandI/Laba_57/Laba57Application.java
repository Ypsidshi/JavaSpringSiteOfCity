package MandI.Laba_57;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Laba57Application {

	public static void main(String[] args) {
		SpringApplication.run(Laba57Application.class, args);
	}

}
