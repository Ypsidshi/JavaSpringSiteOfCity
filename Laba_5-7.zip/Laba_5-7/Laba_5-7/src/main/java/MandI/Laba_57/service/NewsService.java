package MandI.Laba_57.service;

import MandI.Laba_57.models.File;
import MandI.Laba_57.models.News;
import MandI.Laba_57.repository.NewsRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class NewsService {
    private final NewsRepository newsRepository;

    public void createNews(News news, MultipartFile multiFile) throws IOException {
        if (multiFile.getSize() != 0) {
            File file = toFileEntity(multiFile);
            file.setSize(multiFile.getSize());
            file.setContentType(multiFile.getContentType());
            file.setName(multiFile.getName());
            news.setFile(file);
        }

        newsRepository.save(news);
    }

    private File toFileEntity (MultipartFile multiFile) throws IOException {
        File file = new File();
        file.setName(multiFile.getName());
        file.setOriginalFileName(multiFile.getOriginalFilename());
        file.setContentType(multiFile.getContentType());
        file.setSize(multiFile.getSize());
        file.setBytes(multiFile.getBytes());
        return file;
    }
}
