package MandI.Laba_57.repository;

import MandI.Laba_57.models.News;
import org.springframework.data.repository.CrudRepository;

public interface NewsRepository extends CrudRepository<News, Long> {
}
