package MandI.Laba_57.repository;

import MandI.Laba_57.models.Avatar;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AvatarRepository  extends JpaRepository<Avatar, Long> {
}
