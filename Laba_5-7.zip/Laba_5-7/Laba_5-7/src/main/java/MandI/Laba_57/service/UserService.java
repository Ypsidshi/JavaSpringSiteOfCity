package MandI.Laba_57.service;

import MandI.Laba_57.models.Avatar;
import MandI.Laba_57.models.Enums.Role;
import MandI.Laba_57.models.Image;
import MandI.Laba_57.models.News;
import MandI.Laba_57.models.User;
import MandI.Laba_57.repository.AvatarRepository;
import MandI.Laba_57.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.Principal;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AvatarRepository avatarRepository;
    public boolean createUser(User user) {
        String email = user.getEmail();
        if (userRepository.findByEmail(email) != null) return false;
        user.setActive(true);
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.getRoles().add(Role.USER);
        log.info("Saving new User with email: {}", email);
        userRepository.save(user);
        return true;
    }

    private Avatar toAvatarEntity(MultipartFile file, User user) throws IOException {
        Avatar image = new Avatar();
        image.setName(file.getName());
        image.setOriginalFileName(file.getOriginalFilename());
        image.setContentType(file.getContentType());
        image.setSize(file.getSize());
        image.setBytes(file.getBytes());
        image.setUser(user);
        return image;
    }
    public void uploadAvatar(Principal principal, MultipartFile avatar) throws IOException {
        Avatar image;
        User user = getUserByPrincipal(principal);

        if (avatar.getSize() != 0) {
            if (user.getAvatarId() != null) {
                Avatar old = user.getAvatar();
                avatarRepository.delete(old);
            }
            image = toAvatarEntity(avatar, user);
            avatarRepository.save(image);
            user.setAvatarId(image.getId());
            user.addAvatarToUser(image);

            log.info("Saving new avatar. ");
            userRepository.save(user);
        }

    }

    public void deleteAvatar(String userEmail) {
        User user = userRepository.findByEmail(userEmail);
        if (user != null) {
            Avatar avatar = user.getAvatar();
            if (avatar != null) {
                user.setAvatarId(null);
                userRepository.save(user);
                avatarRepository.delete(avatar);
            }
        }
    }
    public List<User> list(){
        return userRepository.findAll();
    }

    public void banUser(Long id) {
        User user = userRepository.findById(id).orElse(null);
        if (user != null){
            if (user.isActive()){
                user.setActive(false);
                log.info("Ban user with id = {}; email: {}", user.getId(), user.getEmail());
            }
            else{
                user.setActive(true);
                log.info("Unban user with id = {}; email: {}", user.getId(), user.getEmail());
            }

        }
        userRepository.save(user);
    }

    public void changeUserRole(User user, Map<String, String> form) {
        String selectedRole = form.get("selectedRole");
        if (selectedRole != null) {
            user.getRoles().clear();
            user.getRoles().add(Role.valueOf(selectedRole));
            userRepository.save(user);
        }
    }

    public User getUserByPrincipal(Principal principal) {
        if (principal == null) return new User();
        return userRepository.findByEmail(principal.getName());
    }



    public boolean existsById(long id) {
        return userRepository.existsById(id);
    }

    public Optional<User> findById(long id) {
        return userRepository.findById(id);
    }

    public void save(User user) {
        userRepository.save(user);
    }
}