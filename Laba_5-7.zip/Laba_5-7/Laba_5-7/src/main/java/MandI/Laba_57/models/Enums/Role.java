package MandI.Laba_57.models.Enums;

import org.springframework.security.core.GrantedAuthority;

public enum Role implements GrantedAuthority {
    USER,MODER,ADMIN;

    @Override
    public String getAuthority() {
        return name();
    }
}